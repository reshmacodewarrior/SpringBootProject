package com.universityproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UniversityProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
